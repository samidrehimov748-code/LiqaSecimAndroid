package com.example.liqasecim

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.content.SharedPreferences
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var listContainer: LinearLayout
    private lateinit var countLabel: TextView
    private val leagues = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("league_storage", Context.MODE_PRIVATE)
        loadLeagues()
        buildScreen()
        renderLeagues()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(12))
            setBackgroundColor(0xFFF6F8F6.toInt())
        }

        val title = TextView(this).apply {
            text = "⚽ Mənim liqalarım"
            textSize = 26f
            setTextColor(0xFF164E2D.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Yalnız öz əlavə etdiyin liqalar burada görünəcək."
            textSize = 14f
            setTextColor(0xFF59645C.toInt())
            setPadding(0, dp(8), 0, dp(18))
        }
        root.addView(subtitle)

        val addButton = Button(this).apply {
            text = "+ Liqa əlavə et"
            textSize = 16f
            setOnClickListener { showAddDialog() }
        }
        root.addView(addButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
        ))

        countLabel = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFF164E2D.toInt())
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(20), 0, dp(8))
        }
        root.addView(countLabel)

        val scroll = ScrollView(this)
        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(listContainer)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val footer = TextView(this).apply {
            text = "Növbəti mərhələdə oyunları və 2,5 ÜST analizini əlavə etmək olar."
            textSize = 12f
            setTextColor(0xFF69736B.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(footer)

        setContentView(root)
    }

    private fun showAddDialog() {
        val input = EditText(this).apply {
            hint = "Məsələn: İngiltərə — Premyer Liqa"
            singleLine = true
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        val wrapper = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Yeni liqa")
            .setView(wrapper)
            .setNegativeButton("Ləğv et", null)
            .setPositiveButton("Əlavə et", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = input.text.toString().trim()
                when {
                    name.isBlank() -> input.error = "Liqa adını yaz"
                    leagues.any { it.equals(name, ignoreCase = true) } ->
                        input.error = "Bu liqa artıq əlavə olunub"
                    else -> {
                        leagues.add(name)
                        saveLeagues()
                        renderLeagues()
                        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                            .hideSoftInputFromWindow(input.windowToken, 0)
                        dialog.dismiss()
                        Toast.makeText(this, "Liqa əlavə edildi", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        dialog.show()
    }

    private fun renderLeagues() {
        listContainer.removeAllViews()
        countLabel.text = "Əlavə etdiyin liqalar: ${leagues.size}"

        if (leagues.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Hələ liqa əlavə etməmisən.\nBaşlamaq üçün “Liqa əlavə et” düyməsinə bas."
                textSize = 16f
                setTextColor(0xFF68736A.toInt())
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(36), dp(16), dp(36))
            }
            listContainer.addView(empty)
            return
        }

        leagues.forEach { league ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(8), dp(8), dp(8))
                setBackgroundColor(0xFFFFFFFF.toInt())
            }

            val name = TextView(this).apply {
                text = "🏆  $league"
                textSize = 16f
                setTextColor(0xFF26352A.toInt())
                setPadding(0, dp(8), dp(8), dp(8))
            }
            row.addView(name, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            val delete = Button(this).apply {
                text = "Sil"
                textSize = 12f
                setOnClickListener { confirmDelete(league) }
            }
            row.addView(delete)

            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.bottomMargin = dp(8)
            listContainer.addView(row, params)
        }
    }

    private fun confirmDelete(league: String) {
        AlertDialog.Builder(this)
            .setTitle("Liqanı silmək?")
            .setMessage("“$league” siyahıdan silinsin?")
            .setNegativeButton("Xeyr", null)
            .setPositiveButton("Bəli") { _, _ ->
                leagues.removeAll { it == league }
                saveLeagues()
                renderLeagues()
            }
            .show()
    }

    private fun saveLeagues() {
        val json = JSONArray()
        leagues.forEach { json.put(it) }
        prefs.edit().putString("leagues", json.toString()).apply()
    }

    private fun loadLeagues() {
        leagues.clear()
        val raw = prefs.getString("leagues", "[]") ?: "[]"
        try {
            val json = JSONArray(raw)
            for (i in 0 until json.length()) {
                leagues.add(json.getString(i))
            }
        } catch (_: Exception) {
            prefs.edit().putString("leagues", "[]").apply()
        }
    }
}
